package cn.dfxy.training;

public class Main {
    public static void main(String[] args) {
        NumGame numGame = new NumGame();
        numGame.start();

    }
}
